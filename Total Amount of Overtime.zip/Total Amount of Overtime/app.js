function start() {  
    "use strict";
    document.getElementById("sb").disabled = true;
    document.getElementById("overn").disabled = true;
    document.getElementById("overp").disabled = true;
 
    document.getElementById("overn").style.backgroundColor = "#E6E6E6";
    document.getElementById("overp").style.backgroundColor = "#E6E6E6";
}
 
function isNumber(x) {
    "use strict";
    if (isNaN(x.value)) {
        x.style.backgroundColor = "red";
        document.getElementById("sb").disabled = true;
        document.getElementById("overn").value = '';
        document.getElementById("overp").value = '';
 
        document.getElementById("overn").style.backgroundColor = "#E6E6E6";
        document.getElementById("overp").style.backgroundColor = "#E6E6E6";
 
        alert("Please Enter a valid number!");
    } else {
        // it is a number
        x.style.backgroundColor = null;
        document.getElementById("sb").disabled = false;
    }
}
 
function compute() {
    "use strict";
    var numberOfWorkingHours = document.getElementById("WH").value, regularPrice = document.getElementById("price").value, numberOfOvertimeHours = 0, totalPrice = 0, i;
 
    if (numberOfWorkingHours > 20) {
        numberOfOvertimeHours = numberOfWorkingHours - 20;
 
        for (i = 1; i <= numberOfOvertimeHours; i += 1) {
            if (i <= 5) {
                totalPrice += regularPrice * 1.5;
            } else if (i <= 10) {
                totalPrice += regularPrice * 1.75;
            } else {
                totalPrice += regularPrice * 2.00;
            }
        }
    }
 
    document.getElementById("overn").value = numberOfOvertimeHours;
    document.getElementById("overp").value = totalPrice;
 
    document.getElementById("overn").style.backgroundColor = "white";
    document.getElementById("overp").style.backgroundColor = "white";
 
}